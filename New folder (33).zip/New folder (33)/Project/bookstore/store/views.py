from django.shortcuts import render

# Create your views here.
def home(request):
    book=[
        { "title":"Can we be Strangers again?","author":"Shrijeet Shandilya","Price":1500}
        { "title":"amma dairy lo konni pagelu","author":"ravi mantri"."Price":1000}
        { "title":"Pride and Prejudice","author":"Jane Austen","Price":1200}
        { "title":"The Great Gatsby","author":"F. Scott Fitzgerald","Price":1000}
        { "title":"1984","author":"George Orwell","Price":1100}
    ]
return render(request, 'store/index.html',{'books':books})