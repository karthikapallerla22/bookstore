from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('contact/', views.contact_view, name='contact'),
    path('categories/', views.categories, name='categories'),
    path('book/<int:book_id>/', views.book_detail, name='book_detail'),
    path('transaction/', views.transaction, name='transaction'),
    path('confirmation/', views.confirmation, name='order_success'),
    path('orders/', views.order_history, name='orders_history'),
    path('help/', views.help_page, name='help'),  
]
