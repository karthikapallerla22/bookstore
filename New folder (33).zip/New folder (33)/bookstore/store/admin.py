from django.contrib import admin
from .models import Book, Orders

admin.site.register(Book)
admin.site.register(Orders)
