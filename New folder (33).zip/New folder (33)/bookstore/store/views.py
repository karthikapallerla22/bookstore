from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import Order
def home(request):
    books = [
        {'id': 1, 'title': 'The Midnight Library', 'price': 499, 'image': 'https://m.media-amazon.com/images/I/81eA+LfVz5L._SL1500_.jpg'},
        {'id': 2, 'title': 'Ikigai', 'price': 299, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
        {'id': 3, 'title': 'Rich Dad Poor Dad', 'price': 399, 'image': 'https://m.media-amazon.com/images/I/81bsw6fnUiL._SL1500_.jpg'},
        {'id': 4, 'title': 'Deep Work', 'price': 429, 'image': 'https://m.media-amazon.com/images/I/61H0K8C4vZL._SL1500_.jpg'},
        {'id': 5, 'title': 'The Psychology of Money', 'price': 349, 'image': 'https://m.media-amazon.com/images/I/71g2ednj0JL._SL1500_.jpg'},
        {'id': 6, 'title': 'Atomic Habits', 'price': 450, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
    ]
    return render(request, 'store/home.html', {'books': books})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'store/login.html')

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        if password == confirm_password:
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already exists.')
            else:
                User.objects.create_user(username=username, password=password)
                return redirect('login')
        else:
            messages.error(request, 'Passwords do not match.')
    return render(request, 'store/register.html')
def categories(request):
    return render(request, 'store/categories.html')
def contact_view(request):
    return render(request, 'store/contact.html')
def book_detail(request, book_id):
    books = [
        {'id': 1, 'title': 'The Midnight Library', 'price': 499, 'image': 'https://m.media-amazon.com/images/I/81eA+LfVz5L._SL1500_.jpg'},
        {'id': 2, 'title': 'Ikigai', 'price': 299, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
        {'id': 3, 'title': 'Rich Dad Poor Dad', 'price': 399, 'image': 'https://m.media-amazon.com/images/I/81bsw6fnUiL._SL1500_.jpg'},
        {'id': 4, 'title': 'Deep Work', 'price': 429, 'image': 'https://m.media-amazon.com/images/I/61H0K8C4vZL._SL1500_.jpg'},
        {'id': 5, 'title': 'The Psychology of Money', 'price': 349, 'image': 'https://m.media-amazon.com/images/I/71g2ednj0JL._SL1500_.jpg'},
        {'id': 6, 'title': 'Atomic Habits', 'price': 450, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
    ]

    book = next((b for b in books if b['id'] == book_id), None)
    if not book:
        return render(request, 'store/404.html', status=404)

    return render(request, 'store/book_detail.html', {'book': book})
@login_required(login_url='/login/')
def order_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-ordered_at')
    return render(request, 'store/order_history.html', {'orders': orders})
def transaction(request):
    title = request.GET.get("title")
    price = request.GET.get("price")
    if not title or not price:
        return redirect('home')
    return render(request, 'store/transaction.html', {'title': title, 'price': price})
def confirmation(request):
    return render(request, 'store/order_success.html')
def help_page(request):
    return render(request, 'store/help.html')
